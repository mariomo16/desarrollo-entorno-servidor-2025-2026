<?php
    
    class Usuario {
        private $id;
        private $nickname;
        private $email;
        private $password;

        public function __construct($id = null, $nickname = null, $email = null, $password = null) {
            $this->id = $id;
            $this->nickname = $nickname;
            $this->email = $email;
            $this->password = $password;
        }

        public function getId() {
            return $this->id;
        }
        
        public function setId($id) {
            $this->id = $id;
        }

        public function getNickname() {
            return $this->nickname;
        }

        public function setNickname($nickname) {
            $this->nickname = $nickname;
        }
        
        public function getEmail() {
            return $this->email;
        }

        public function setEmail($email) {
            $this->email = $email;
        }

        public function getPassword() {
            return $this->password;
        }
        
        public function setPassword($password) {
            $this->password = $password;
        }

    }

?>