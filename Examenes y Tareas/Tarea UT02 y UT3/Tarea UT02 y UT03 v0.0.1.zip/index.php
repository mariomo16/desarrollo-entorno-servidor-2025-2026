<?php
require_once "catalogo_productos.php";


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['productos'])) {
    $productos = $_POST['productos'];
    ?>
    
    <table border="1">
        <tr>
            <?php for ($i = 0; $i < count($productos); $i++) { ?>
                <th><?php echo $productos[$i]["id"]; ?></th>
            <?php } ?>
        </tr>
        <tr>
            <?php for ($i = 0; $i < count($productos); $i++) { ?>
                <td><?php echo $productos[$i]["nombre"]; ?></td>
            <?php } ?>
        </tr>
    </table>
    
    <?php
}
?>

function filtrar_igual($productos, $categoria, $valor)
{
    return array_filter($productos, function ($item) use ($categoria, $valor) {
        return $item[$categoria] == $valor;
    }, ARRAY_FILTER_USE_KEY);
}

function filtrar_mayor_que($productos, $categoria, $valor)
{
    
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <label for="filtro">Función de f
        <hr>
        <form action="" method="POST">
            <label for="">Campo a seleccionar: </label>
            <?php
            for ($i = 0; $i < count($productos) - 1; $i++) {
                $name = array_keys($productos[0])[$i];
                echo "<label for=\"$name\">$name</label>";
                echo "<input type=\"checkbox\" name=\"campo_seleccionar[]\" id=\"$name\">";
            }
            ; ?>
            <br>
            <label for="filtro">Campo a filtrar</label>
            <select name="filtro" id="filtro" value="Sin campo">
                <option value="">Sin campo</option>
                <?php
                for ($i = 0; $i < count($productos) - 1; $i++) {
                    $name = array_keys($productos[0])[$i];
                    echo "<option value=\"$name\">$name</option>";
                }
                ; ?>
            </select>
            <br>
            <label for="">Función de filtrado</label>
            <select name="funcFiltro" id="funcFiltro">
                <option value="">Sin filtrado</option>
                <option value="igual">Igual a</option>
                <option value="contiene">Contiene</option>
                <option value="mayorque">Mayor que</option>
                <option value="menorque">Menor que</option>

            </select>
            <br>
            <label for="criterio">Criterio</label>
            <input type="text" name="criterio" id="criterio">
            <br>
            <input type="submit" value="Enviar">
        </form>
</body>

</html>