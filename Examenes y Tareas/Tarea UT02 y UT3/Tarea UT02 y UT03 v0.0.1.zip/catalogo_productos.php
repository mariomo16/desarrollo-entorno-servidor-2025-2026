<?php
$productos = [
    [
        "id" => 1,
        "nombre" => "Laptop Gaming",
        "categoria" => "Electronica",
        "stock" => 15,
        "precio" => 1200.50
    ],
    [
        "id" => 2,
        "nombre" => "Teclado Mecánico",
        "categoria" => "Accesorios",
        "stock" => 50,
        "precio" => 80.00
    ],
    [
        "id" => 3,
        "nombre" => "Monitor UHD",
        "categoria" => "Electronica",
        "stock" => 10,
        "precio" => 450.75
    ],
    [
        "id" => 4,
        "nombre" => "Silla Gaming",
        "categoria" => "Mobiliario",
        "stock" => 25,
        "precio" => 180.00
    ],
    [
        "id" => 5,
        "nombre" => "Ratón Óptico",
        "categoria" => "Accesorios",
        "stock" => 100,
        "precio" => 25.20
    ],
    [
        "id" => 6,
        "nombre" => "Webcam UHD",
        "categoria" => "Accesorios",
        "stock" => 30,
        "precio" => 65.00
    ]
];
