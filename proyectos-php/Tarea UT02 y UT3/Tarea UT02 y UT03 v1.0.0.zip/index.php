<?php
require_once "catalogo_productos.php";

/*
$campos_seleccionados = array_keys($productos[0]);

echo "<table id=\"tabla\">";
echo "<tr>";
foreach ($campos_seleccionados as $campo) {
    echo "<th>" . ucfirst($campo) . "</th>";
}
echo "</tr>";
foreach ($productos as $producto) {
    echo "<tr>";
    foreach ($campos_seleccionados as $campo) {
        echo "<td>" . $producto[$campo] . "</td>";
    }
    echo "</tr>";
}
echo "</table";
*/

function filtrar_igual($productos, $campo, $valor)
{
    return array_filter($productos, function ($producto) use ($campo, $valor) {
        return $producto[$campo] && $producto[$campo] == $valor;
    });
}

function filtrar_mayor_que($productos, $campo, $valor)
{
    return array_filter($productos, function ($producto) use ($campo, $valor) {
        return $producto[$campo] && is_numeric($producto[$campo]) && $producto[$campo] > $valor;
    });
}

function filtrar_menor_que($productos, $campo, $valor)
{
    return array_filter($productos, function ($producto) use ($campo, $valor) {
        return $producto[$campo] && is_numeric($producto[$campo]) && $producto[$campo] < $valor;
    });
}

// https://stackoverflow.com/questions/33056701/array-match-values-filter-php
function filtrar_contiene($productos, $campo, $valor)
{
    return array_filter($productos, function ($producto) use ($campo, $valor) {
        return $producto[$campo] && stripos($producto[$campo], $valor) !== false;
    });
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los campos seleccionados
    $campos_seleccionados = $_POST['campos_seleccionados'] ?? [];

    $productos_filtrados = $productos;
    $campo_filtrar = $_POST['campo_filtrar'] ?? '';
    $operador = $_POST['operador'] ?? '';
    $valor = $_POST['valor'] ?? '';

    if ($campo_filtrar && $operador && $valor !== '') {
        switch ($operador) {
            case 'igualque':
                $productos_filtrados = filtrar_igual($productos_filtrados, $campo_filtrar, $valor);
                break;
            case 'mayorque':
                $productos_filtrados = filtrar_mayor_que($productos_filtrados, $campo_filtrar, $valor);
                break;
            case 'menorque':
                $productos_filtrados = filtrar_menor_que($productos_filtrados, $campo_filtrar, $valor);
                break;
            case 'contiene':
                $productos_filtrados = filtrar_contiene($productos_filtrados, $campo_filtrar, $valor);
                break;
        }
    }

    if (empty($campos_seleccionados)) {
        $campos_seleccionados = array_keys($productos[0]);
    }

    if (!empty($productos_filtrados)) {
        echo "<table>";
        echo "<tr>";
        foreach ($campos_seleccionados as $campo) {
            echo "<th>" . ucfirst($campo) . "</th>";
        }
        echo "</tr>";
        foreach ($productos_filtrados as $producto) {
            echo "<tr>";
            foreach ($campos_seleccionados as $campo) {
                echo "<td>" . $producto[$campo] . "</td>";
            }
            echo "</tr>";
        }
        echo "</tr>";
        echo "</table";
    } else {
        echo "<p>No se han encontrado productos con los criterios especificados.</p>";
    }

}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catálogo de Productos</title>
    <style>
        :root {
            font-family: sans-serif, Arial;
        }

        table,
        tr,
        th,
        td {
            border: 1px solid gray;
            border-collapse: collapse;
            text-align: center;
            padding: 2px 5px;
        }
    </style>
</head>

<body>
    <hr>
    <form action="" method="POST">
        <label>Campos a seleccionar: </label>
        <?php
        $campos = array_keys($productos[0]);
        foreach ($campos as $name) {
            echo "<label for=\"$name\">$name</label>";
            echo "<input type=\"checkbox\" name=\"campos_seleccionados[]\" id=\"$name\" value=\"$name\">";
        }
        ?>
        <br><br>

        <label for="campo_filtrar">Campo a filtrar:</label>
        <select name="campo_filtrar" id="campo_filtrar">
            <option value="">Sin campo</option>
            <?php
            foreach ($campos as $name) {
                echo "<option value=\"$name\">$name</option>";
            }
            ?>
        </select>
        <br><br>

        <label for="operador">Función de filtrado:</label>
        <select name="operador" id="operador">
            <option value="">Sin filtrado</option>
            <option value="igualque">Igual a</option>
            <option value="contiene">Contiene</option>
            <option value="mayorque">Mayor que</option>
            <option value="menorque">Menor que</option>
        </select>
        <br><br>

        <label for="valor">Criterio:</label>
        <input type="text" name="valor" id="valor">
        <br><br>

        <input type="submit" value="Enviar">
    </form>
</body>

</html>